package com.example.tema2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class recyclerAdapter extends RecyclerView.Adapter<recyclerAdapter.MyViewHolder> {

    private final ArrayList<Student> usersList;

    public recyclerAdapter(ArrayList<Student> usersList){
        this.usersList = usersList;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        private final TextView nameTxt;
        private recyclerAdapter adapter;

        public MyViewHolder(final View view) {
            super(view); //super = class
            nameTxt = view.findViewById(R.id.textView2);
            itemView.findViewById(R.id.delete).setOnClickListener( view1 ->{
                adapter.usersList.remove(getAdapterPosition());
                adapter.notifyItemRemoved(getAdapterPosition());
           });
        }

        public MyViewHolder linkAdapter(recyclerAdapter adapter){
            this.adapter = adapter;
            return this;
        }
    }


    @NonNull
    @Override
    public recyclerAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_items, parent, false);
        return new MyViewHolder(itemView).linkAdapter(this);
    }

    @Override
    public void onBindViewHolder(@NonNull recyclerAdapter.MyViewHolder holder, int position) {

        String name = usersList.get(position).getUsername();
        holder.nameTxt.setText(name);
    }

    @Override
    public int getItemCount() {
        return usersList.size();
    }
} //public class recyclerAdapter
