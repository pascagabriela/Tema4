package com.example.tema2;

public class Student {

    private String username;

    public Student(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

}
