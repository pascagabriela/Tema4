package com.example.tema2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {

    private ArrayList<Student> usersList;
    private RecyclerView recyclerViewMain;
    recyclerAdapter adapter;
    List<String> names = new ArrayList<>();
    Button add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        EditText name = findViewById(R.id.Name);

        names.add("Pop Cristian");
        names.add("Vasilescu Mihai");
        recyclerViewMain = findViewById(R.id.recyclerViewMain);
        usersList = new ArrayList<>();
        setUserInfo();
        setAdapter();
        adapter = new recyclerAdapter(usersList);
        add = findViewById(R.id.add);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(name.getText().length()>0) {
                    names.add(String.valueOf(name.getText()));
                    usersList.add(new Student(names.get(names.size()-1)));
                    setAdapter();
                }
            }
        });
    }

    private void setAdapter() {
        recyclerAdapter adapter = new recyclerAdapter(usersList);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerViewMain.setLayoutManager(layoutManager);
        recyclerViewMain.setItemAnimator(new DefaultItemAnimator());
        recyclerViewMain.setAdapter(adapter);
    }

    private void setUserInfo(){
        for (int i = 0; i<names.size(); i++){
            usersList.add(new Student(names.get(i)));
        } //end for
    }//setUserInfo

    public void Back(View view){
        Intent intent_2 = new Intent(this, MainActivity.class);
        startActivity(intent_2);
    }
}